<!DOCTYPE html>
<html>
<head>
<style>
* {box-sizing: border-box;}

body { 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.header {
  overflow: hidden;
  background-color: #f1f1f1;
  padding: 20px 10px;
}

.header a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;
}

.header a.logo {
  font-size: 25px;
  font-weight: bold;
}

.header a:hover {
  background-color: #ddd;
  color: black;
}

.header a.active {
  background-color: dodgerblue;
  color: white;
}

.header-right {
  float: right;
}

@media screen and (max-width: 500px) {
  .header a {
    float: none;
    display: block;
    text-align: left;
  }
  
  .header-right {
    float: none;
  }
}
.footer {
  position: absolute;
  right: 0;
  bottom: 0;
  left: 0;
  padding: 1rem;
  background-color: #efefef;
  text-align: center;
}
</style>

<style>
* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
}

/* Float four columns side by side */
.column {
  float: left;
  width: 25%;
  padding: 0 10px;
}


.row {margin: 0 -5px;}


.row:after {
  content: "";
  display: table;
  clear: both;
}


@media screen and (max-width: 600px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 20px;
  }
}


.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: #f1f1f1;
}
</style>
</head>
<body style=" background-image: linear-gradient(to right, Blue, white)";>
<div class="header" style="background-image: linear-gradient(red, yellow)";>
  <a href="https://workbenchprojects.com/" class="logo">Work Bench</a>
  <div class="header-right">
    
    <a href="logout.php">Logout</a>
  </div>
</div>
<div class="row" style="padding: 35px";>
<div class="column">
    <div class="card">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "register";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT id, username, email FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
   

   echo "<br> id: ". $row["id"]. " - Name: ". $row["username"]. " " . $row["email"] . "<br>";
    }
} else {
    echo "0 results";
}

$conn->close();
?> 
<div>
</div>
</div>
<div class="footer" style="background-image: linear-gradient(red, yellow)";>We are the very first makerspace, Fablab and co-working space that has reclaimed a public space from the government for all the thirsty makers, tinkerers, innovators and entrepreneurs of Bangalore. With 5000 sq. ft. of pure creative awesomeness right under the Halasuru Metro Station, you can simply bring your thoughts, ideas and designs to this playground and walk out with its manifestation in your hands.</div>

</body>
</html>